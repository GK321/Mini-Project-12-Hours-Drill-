Initial Balance : 50000
Deposited Amount : 55000
Deposited Amount : 55800
Withdrawal Amount : 54800